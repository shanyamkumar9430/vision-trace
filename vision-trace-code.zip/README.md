# Vision Trace

Intelligent Traffic Anomalies & Smart City Video Surveillance Network

## Project Structure

```
vision trace/
├── backend/
│   └── app.py          # Flask backend with YOLOv8 and DeepSORT
├── frontend/
│   ├── index.html      # Main UI page
│   ├── style.css       # Styles
│   └── app.js          # Frontend logic
└── requirements.txt    # Python dependencies
```

## Setup Instructions

### 1. Install Python Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run Backend

```bash
cd backend
python app.py
```

Backend will start on http://localhost:5000

### 3. Open Frontend

Simply open `frontend/index.html` in your browser.

## Features

- **Vehicle Detection**: Uses YOLOv8 to detect cars, motorcycles, buses, and trucks
- **Tracking**: Uses DeepSORT to track vehicles across frames
- **Anomaly Detection**: Detects sudden stops (stalls) and collisions
- **Real-time Alerts**: Shows alerts with sound notifications in the UI

## Notes

- The MongoDB integration is currently commented out - you can uncomment it to persist alerts
- By default, the backend uses your webcam. You can modify `video_source` in `app.py` or pass a video path via the `/api/start` endpoint
- The frontend uses a sample video for demonstration purposes
