from flask import Flask, jsonify, request
from flask_cors import CORS
import cv2
import numpy as np
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort
import threading
import time
from collections import defaultdict
import uuid
import datetime
import os

app = Flask(__name__)
CORS(app)

# Global variables
video_source = 0  # Default to webcam, can be replaced with video file or stream URL
cap = None
running = False
detection_thread = None
tracker = DeepSort(max_age=30)
model = YOLO('yolov8n.pt')
vehicle_classes = [2, 3, 5, 7]  # car, motorcycle, bus, truck

# Vehicle tracking data
vehicle_data = defaultdict(lambda: {'positions': [], 'timestamps': [], 'speed': 0})
alerts = []

# MongoDB client placeholder (in real scenario, you'd connect here)
# from pymongo import MongoClient
# client = MongoClient('mongodb://localhost:27017/')
# db = client['visiontrace']
# alerts_collection = db['alerts']

def process_video():
    global cap, running, vehicle_data, alerts
    while running and cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        current_time = time.time()

        # Run YOLO detection
        results = model(frame, stream=True)

        detections = []
        for result in results:
            boxes = result.boxes
            for box in boxes:
                x1, y1, x2, y2 = box.xyxy[0].tolist()
                conf = box.conf[0].item()
                cls = int(box.cls[0].item())
                if cls in vehicle_classes and conf > 0.5:
                    detections.append(([x1, y1, x2 - x1, y2 - y1], conf, cls))

        # Update tracker
        tracks = tracker.update_tracks(detections, frame=frame)

        # Process tracks
        current_vehicles = []
        for track in tracks:
            if not track.is_confirmed():
                continue
            track_id = track.track_id
            ltrb = track.to_ltrb()
            x1, y1, x2, y2 = ltrb
            center_x = (x1 + x2) / 2
            center_y = (y1 + y2) / 2

            vehicle_data[track_id]['positions'].append((center_x, center_y))
            vehicle_data[track_id]['timestamps'].append(current_time)

            # Calculate speed
            if len(vehicle_data[track_id]['positions']) > 1:
                pos1 = vehicle_data[track_id]['positions'][-2]
                pos2 = vehicle_data[track_id]['positions'][-1]
                time_diff = vehicle_data[track_id]['timestamps'][-1] - vehicle_data[track_id]['timestamps'][-2]
                if time_diff > 0:
                    distance = np.sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2)
                    speed = distance / time_diff
                    vehicle_data[track_id]['speed'] = speed

            # Check for anomalies
            # Sudden stop (speed drops below threshold)
            if vehicle_data[track_id]['speed'] < 5 and len(vehicle_data[track_id]['positions']) > 10:
                if not any(alert['track_id'] == track_id and alert['type'] == 'stall' for alert in alerts):
                    alert = {
                        'id': str(uuid.uuid4()),
                        'type': 'stall',
                        'track_id': track_id,
                        'timestamp': datetime.datetime.now().isoformat(),
                        'position': {'x': center_x, 'y': center_y}
                    }
                    alerts.append(alert)
                    # In real scenario, insert to MongoDB
                    # alerts_collection.insert_one(alert)

            # Check for collisions (simplified)
            for other_track in tracks:
                if other_track.track_id != track_id and other_track.is_confirmed():
                    other_ltrb = other_track.to_ltrb()
                    ox1, oy1, ox2, oy2 = other_ltrb
                    # Check if bounding boxes overlap
                    if x1 < ox2 and ox1 < x2 and y1 < oy2 and oy1 < y2:
                        if not any(alert['track_id'] == track_id and alert['type'] == 'collision' for alert in alerts):
                            alert = {
                                'id': str(uuid.uuid4()),
                                'type': 'collision',
                                'track_id': track_id,
                                'other_track_id': other_track.track_id,
                                'timestamp': datetime.datetime.now().isoformat(),
                                'position': {'x': (center_x + (ox1 + ox2)/2)/2, 'y': (center_y + (oy1 + oy2)/2)/2}
                            }
                            alerts.append(alert)
                            # In real scenario, insert to MongoDB
                            # alerts_collection.insert_one(alert)

            current_vehicles.append({
                'track_id': track_id,
                'bbox': [x1, y1, x2, y2],
                'speed': vehicle_data[track_id]['speed'],
                'position': {'x': center_x, 'y': center_y}
            })

        # Keep last 10 seconds of data
        for track_id in list(vehicle_data.keys()):
            while len(vehicle_data[track_id]['timestamps']) > 0 and current_time - vehicle_data[track_id]['timestamps'][0] > 10:
                vehicle_data[track_id]['positions'].pop(0)
                vehicle_data[track_id]['timestamps'].pop(0)
            if len(vehicle_data[track_id]['timestamps']) == 0:
                del vehicle_data[track_id]

        # Broadcast data (in real app, use WebSocket)
        # For this example, we'll just store the latest frame data in memory

        time.sleep(0.03)  # ~30 FPS

@app.route('/api/start', methods=['POST'])
def start_processing():
    global running, detection_thread, cap
    if running:
        return jsonify({'status': 'already running'})
    
    # Use sample video if available, else webcam
    video_path = request.json.get('video_path', 0)
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        return jsonify({'status': 'error', 'message': 'Could not open video source'}), 400
    
    running = True
    detection_thread = threading.Thread(target=process_video)
    detection_thread.start()
    return jsonify({'status': 'started'})

@app.route('/api/stop', methods=['POST'])
def stop_processing():
    global running, cap
    running = False
    if detection_thread:
        detection_thread.join()
    if cap:
        cap.release()
    return jsonify({'status': 'stopped'})

@app.route('/api/status', methods=['GET'])
def get_status():
    global running, alerts, vehicle_data
    return jsonify({
        'running': running,
        'alerts': alerts[-20:],  # Last 20 alerts
        'vehicle_count': len(vehicle_data),
        'vehicles': list(vehicle_data.keys())
    })

@app.route('/')
def index():
    return jsonify({'message': 'Vision Trace Backend is running!'})

if __name__ == '__main__':
    app.run(debug=True, port=5000)

