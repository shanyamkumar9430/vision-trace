const API_BASE = 'http://localhost:5000/api';

const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const statusDiv = document.getElementById('status');
const vehicleCountEl = document.getElementById('vehicleCount');
const alertCountEl = document.getElementById('alertCount');
const alertsContainer = document.getElementById('alertsContainer');
const videoFeed = document.getElementById('videoFeed');
const overlayCanvas = document.getElementById('overlayCanvas');
const ctx = overlayCanvas.getContext('2d');

let isRunning = false;
let statusInterval;
let currentAlerts = [];

// Initialize canvas
function initCanvas() {
    overlayCanvas.width = videoFeed.clientWidth;
    overlayCanvas.height = videoFeed.clientHeight;
}

window.addEventListener('resize', initCanvas);
videoFeed.addEventListener('loadedmetadata', initCanvas);

// Start monitoring
startBtn.addEventListener('click', async () => {
    try {
        const response = await fetch(`${API_BASE}/start`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ video_path: 0 })
        });
        
        if (response.ok) {
            isRunning = true;
            startBtn.disabled = true;
            stopBtn.disabled = false;
            statusDiv.textContent = 'Status: Monitoring Active';
            statusDiv.style.color = '#10b981;
            
            statusInterval = setInterval(fetchStatus, 1000);
        }
    } catch (error) {
        console.error('Error starting:', error);
        statusDiv.textContent = 'Status: Error';
    }
});

// Stop monitoring
stopBtn.addEventListener('click', async () => {
    try {
        await fetch(`${API_BASE}/stop`, { method: 'POST' });
        
        isRunning = false;
        startBtn.disabled = false;
        stopBtn.disabled = true;
        statusDiv.textContent = 'Status: Idle';
        statusDiv.style.color = '#e2e8f0';
        
        clearInterval(statusInterval);
    } catch (error) {
        console.error('Error stopping:', error);
    }
});

// Fetch status from backend
async function fetchStatus() {
    try {
        const response = await fetch(`${API_BASE}/status`);
        const data = await response.json();
        
        vehicleCountEl.textContent = data.vehicle_count;
        alertCountEl.textContent = data.alerts.length;
        
        // Check for new alerts
        data.alerts.forEach(alert => {
            if (!currentAlerts.find(a => a.id === alert.id)) {
                currentAlerts.push(alert);
                addAlertToUI(alert);
                playAlertSound(alert.type);
            }
        });
    } catch (error) {
        console.error('Error fetching status:', error);
    }
}

// Add alert to UI
function addAlertToUI(alert) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert-card ${alert.type}`;
    
    const typeText = alert.type === 'collision' ? 'Collision Detected' : 'Vehicle Stall';
    const time = new Date(alert.timestamp).toLocaleTimeString();
    
    alertDiv.innerHTML = `
        <div class="alert-type">${typeText}</div>
        <div class="alert-time">${time}</div>
    `;
    
    alertsContainer.insertBefore(alertDiv, alertsContainer.firstChild);
}

// Play alert sound (simple beep)
function playAlertSound(type) {
    const audioContext = new (window.AudioContext || window.webkitAudioContext);
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = type === 'collision' ? 800 : 500;
    oscillator.type = 'sine';
    
    gainNode.gain.value = 0.1;
    
    oscillator.start();
    
    setTimeout(() => {
        oscillator.stop();
    }, 300);
}

// Initialize
initCanvas();

